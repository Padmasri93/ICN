define([
	"dojo/_base/declare",
	"ecm/widget/layout/_LaunchBarPane",
	"dojo/text!./templates/ACMSearchPluginFeature.html"
],
function(declare,
		_LaunchBarPane,
		template) {
	/**
	 * @name aCMSearchPluginDojo.ACMSearchPluginFeature
	 * @class 
	 * @augments ecm.widget.layout._LaunchBarPane
	 */
	return declare("aCMSearchPluginDojo.ACMSearchPluginFeature", [
		_LaunchBarPane
	], {
		/** @lends aCMSearchPluginDojo.ACMSearchPluginFeature.prototype */

		templateString: template,
		
		// Set to true if widget template contains DOJO widgets.
		widgetsInTemplate: true,

		postCreate: function() {
			this.logEntry("postCreate");
			this.inherited(arguments);
			
			/**
			 * Add custom logic (if any) that should be necessary after the feature pane is created. For example,
			 * you might need to connect events to trigger the pane to update based on specific user actions.
			 */
			
			this.logExit("postCreate");
		},
		
		/**
		 * Optional method that sets additional parameters when the user clicks on the launch button associated with 
		 * this feature.
		 */
		setParams: function(params) {
			this.logEntry("setParams", params);
			
			if (params) {
				
				if (!this.isLoaded && this.selected) {
					this.loadContent();
				}
			}
			
			this.logExit("setParams");
		},

		/**
		 * Loads the content of the pane. This is a required method to insert a pane into the LaunchBarContainer.
		 */
		loadContent: function() {
			this.logEntry("loadContent");
			
			if (!this.isLoaded) {
				/**
				 * Add custom load logic here. The LaunchBarContainer widget will call this method when the user
				 * clicks on the launch button associated with this feature.
				 */
				this.isLoaded = true;
				this.needReset = false;
			}
			
			this.logExit("loadContent");
		},
		/*
		 * It will search the documents based on the given search criteria.
		 */
		searchDocuments:function(){
			console.log("Entering the searchDocuments method...");
			var requetParams = {};
			var criteria = {};
			var test =this.MemberId.get('value');
			var test1 = this.MemberId.get("value");
			console.log(test1,"::::test:::",test);
			//requetParams.memberId = this.memberId.get("value");
			var properties = ["MemberId","MemberName","DocumentCategory","DocumentType","ProviderName"];
			console.log("Total available properties: "+properties.length);
			for(var i=0;i<properties.length;i++){
		    	var propvalues = document.getElementsByName(properties[i]);
				for(var j=0;j<propvalues.length;j++){
					if(propvalues[j].checked){
						console.log("Checked Value is : ",propvalues[j].value);
						var selectedKey = propvalues[j].name;
						var selectedValue = propvalues[j].value;
						var getData = "this."+propvalues[j].name+".get('value')".replace(/["]+/g, '');
						console.log("Before converting : "+getData);
						var metadata = getData;
						console.log("After converting : "+metadata);
						criteria[selectedKey] = selectedValue;
						requetParams[selectedKey] = metadata;
							break;
						}
					}
		}
			console.log(criteria);
			console.log(requetParams);
			
			
	/*		
			var memberIdOption = document.getElementsByName("MemberId");
			debugger;
			for(var i=0;i<memberIdOption.length;i++){
				if(memberIdOption[i].checked){
					console.log("MemberId Checked Value is : ",memberIdOption[i].value);
					var selectedKey = memberIdOption[i].name;
					var selectedValue = memberIdOption[i].value;
					criteria[selectedKey] = selectedValue;
					break;
				}
			}
			debugger;
			console.log("Criteria : "+criteria);*/
		},
		/**
		 * Resets the content of this pane.
		 */
		reset: function() {
			this.logEntry("reset");
			
			/**
			 * This is an option method that allows you to force the LaunchBarContainer to reset when the user
			 * clicks on the launch button associated with this feature.
			 */
			this.needReset = false;
			
			this.logExit("reset");
		}
	});
});
