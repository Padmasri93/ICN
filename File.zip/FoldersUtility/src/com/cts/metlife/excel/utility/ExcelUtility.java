package com.cts.metlife.excel.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility {

	public void getExcelSheet(String filePath) {
		try {
			FileInputStream file = new FileInputStream(new File(filePath));
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet sheet = workbook.getSheetAt(0);
			Iterator<Row> rowIterator = sheet.iterator();
			while(rowIterator.hasNext()){
				Row row = rowIterator.next();
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = (Cell) cellIterator.next();
					if(cell.getCellType() == CellType.STRING){
						System.out.print(cell.getStringCellValue()+"\t");
					}
					else {
						System.out.println("Failed to read cell from the sheet.");
					}
				}
				System.out.println();
			}
		} catch (FileNotFoundException e) {
			System.out.println("ExcelUtility.getExcelSheet().Exception Message: "+e.getMessage());
			e.printStackTrace();
		}catch(IOException io){
			System.out.println("ExcelUtility.getExcelSheet().Exception : "+io.getMessage());
			io.printStackTrace();
		}
	}
	public static void main(String[] args) {
		ExcelUtility excelUtility = new ExcelUtility();
		excelUtility.getExcelSheet("C:\\Users\\p8demo\\Desktop\\Scenario\\Test\\Testing.xlsx");
	}

}
