package com.cts.ml.folder;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FolderUtilities {

	/*
	 * This method to get the names of all files and directories in the given folder path
	 */
/*	public void listFiles(String path) {
		File folder = new File(path);
		String[] files = folder.list();
		for(String file: files){
			System.out.println(file);
		}
 	}*/
	public void listFiles(String path) throws IOException {
		File folder = new File(path);
		File[] files = folder.listFiles();
		for(File file:files){
			System.out.println("File Name:"+file.getName());
			System.out.println("getAbsolutePath : "+file.getAbsolutePath());
			System.out.println("getName: "+file.getName());
			System.out.println("getPath: "+file.getPath());
			String fileName = file.getName();
			String source = file.getPath();
			moveFile(source,fileName);
		}
 	}
	public void moveFile(String source,String fileName) throws IOException {
		System.out.println("FolderUtilities.moveFile()");
		System.out.println(source);
		String parentTarget = "C:\\Users\\p8demo\\Desktop\\Scenario\\Success\\";
		String target = parentTarget+"\\"+fileName;
		System.out.println("Actual target path : "+target);
		Path temp = Files.move(Paths.get(source), Paths.get(target)); 
		if(temp != null){
			System.out.println("File moved successfully.");
		}
		else{
			System.out.println("Fails to move.");
		}
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FolderUtilities folderUtilities = new FolderUtilities();
		folderUtilities.listFiles("C:\\Users\\p8demo\\Desktop\\Scenario\\Test\\");
		

	}

}
