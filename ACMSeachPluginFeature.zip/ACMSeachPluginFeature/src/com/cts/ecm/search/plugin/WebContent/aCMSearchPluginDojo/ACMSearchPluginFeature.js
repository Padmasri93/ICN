define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/dom-attr",
	"dojo/dom-style",
	"dojo/dom-construct",
	"dojox/layout/TableContainer",
	"dijit/form/TextBox",
	"ecm/widget/layout/_LaunchBarPane",
	"dojo/text!./templates/ACMSearchPluginFeature.html"
],
function(declare,
		lang,
		domAttr,
		domStyle,
		domConstruct,
		TableContainer,
		TextBox,
		_LaunchBarPane,
		template) {
	/**
	 * @name aCMSearchPluginDojo.ACMSearchPluginFeature
	 * @class 
	 * @augments ecm.widget.layout._LaunchBarPane
	 */
	return declare("aCMSearchPluginDojo.ACMSearchPluginFeature", [
		_LaunchBarPane
	], {
		/** @lends aCMSearchPluginDojo.ACMSearchPluginFeature.prototype */

		templateString: template,
		
		// Set to true if widget template contains DOJO widgets.
		widgetsInTemplate: true,

		postCreate: function() {
			this.logEntry("postCreate");
			this.inherited(arguments);
			
			/**
			 * Add custom logic (if any) that should be necessary after the feature pane is created. For example,
			 * you might need to connect events to trigger the pane to update based on specific user actions.
			 */
			
			this.logExit("postCreate");
		},
		
		/**
		 * Optional method that sets additional parameters when the user clicks on the launch button associated with 
		 * this feature.
		 */
		setParams: function(params) {
			this.logEntry("setParams", params);
			
			if (params) {
				
				if (!this.isLoaded && this.selected) {
					this.loadContent();
				}
			}
			
			this.logExit("setParams");
		},

		/**
		 * Loads the content of the pane. This is a required method to insert a pane into the LaunchBarContainer.
		 */
		loadContent: function() {
			this.logEntry("loadContent");
			
			if (!this.isLoaded) {
				/**
				 * Add custom load logic here. The LaunchBarContainer widget will call this method when the user
				 * clicks on the launch button associated with this feature.
				 */
				this.isLoaded = true;
				this.needReset = false;
			}
			
			this.logExit("loadContent");
		},
		/*
		 * Search the documents based on the given search criteria
		 */
		searchDocuments: function(){
			console.log("searching the documents");
			
		},
		/*
		 * Cancel the entered input
		 */
		cancel:function(){
			console.log("resetting the field values.");
		},
		/**
		 * Resets the content of this pane.
		 */
		reset: function() {
			this.logEntry("reset");
			
			/**
			 * This is an option method that allows you to force the LaunchBarContainer to reset when the user
			 * clicks on the launch button associated with this feature.
			 */
			this.needReset = false;
			
			this.logExit("reset");
		}
	});
});
