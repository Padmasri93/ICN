define([
	"dojo/_base/declare",
	"dijit/form/Button",
	"ecm/model/Desktop",
	"ecm/model/ContentItem",
	"ecm/model/Repository",
	"ecm/widget/dialog/AddContentItemDialog",
	"ecm/model/Item",
	"dojo/_base/lang",
	"dojo/dom-style",
	"dojo/query",
	"dojo/aspect",
	"ecm/widget/dialog/BaseDialog",
	"ecm/widget/dialog/ConfirmationDialog",
	"ecm/widget/layout/_LaunchBarPane",
	"dojo/text!./templates/AddDocumentET.html"
],
function(declare,
		Button,
		Desktop,
		ContentItem,
		Repository,
		AddContentItemDialog,
		Item,
		lang,
		domStyle,
		query,
		aspect,
		BaseDialog,
		ConfirmationDialog,
		_LaunchBarPane,
		template) {
	/**
	 * @name sampleEntryTemplateDojo.AddDocumentET
	 * @class 
	 * @augments ecm.widget.layout._LaunchBarPane
	 */
	return declare("sampleEntryTemplateDojo.AddDocumentET", [
		_LaunchBarPane,
	], {
		/** @lends sampleEntryTemplateDojo.AddDocumentET.prototype */

		templateString: template,
		
		// Set to true if widget template contains DOJO widgets.
		widgetsInTemplate: true,
		repository : null,
		addContentItem:null,
		parentFolder:null,
		typeDocument:null,
		virtualItems:null,
		callback:null,
		postCreate: function() {
			this.logEntry("postCreate");
			this.inherited(arguments);
			var repositoryID = ecm.model.desktop.defaultRepositoryId;
			this.repository = ecm.model.desktop.getRepository(repositoryID);
			console.log(repositoryID);

			
			/**
			 * Add custom logic (if any) that should be necessary after the feature pane is created. For example,
			 * you might need to connect events to trigger the pane to update based on specific user actions.
			 */
			
			this.logExit("postCreate");
		},
		/*This method is for adding the document using Document Entry template class with propertyDefinitions
		And to hide the specific property template(property) 
		*/
		addDocument:function(){
			console.log("this.Repository   : ", this.repository);
/*			
			var rep = ecm.model.desktop.getRepository(ecm.model.desktop.defaultRepositoryId);
			console.log("GetRepository   : ", rep);
*/
			var addContentItemDialog = new AddContentItemDialog({});
			var objectStore = this.repository.objectStoreName;
			console.log(objectStore);
			//change
			/*aspect.after(addContentItemDialog.addContentItemPropertiesPane, "onCompleteRendering", function() {
		        addContentItemDialog.addContentItemPropertiesPane.setPropertyValue("sales_prospect_name", "Vara");
		        addContentItemDialog.addContentItemPropertiesPane.setPropertyValue("sales_times_contacted", "4");
		    }, true);
		    addContentItemDialog.show(repository, null, true, false, null, null, false, null);*/
		    //change
			//var deferred =this.repository.getEntryTemplateById("34646C8F-AE2F-4FB3-8E08-BABB6CE57C24", "SalesProspectEntryTemplate", objectStore);
			
			
			/*this.repository.retrieveEntryTemplates(function(templates){
				console.log("templates:  ",templates);
				console.log("thisss.templates: ",templates[0]);
			}, null, null, null, objectStore);
			console.log("Entry Template:  ",et);*/
			
			this.repository.retrieveEntryTemplates(lang.hitch(this,function(templates){
				console.log("Repository  : ",this.repository);
				templates[0].retrieveEntryTemplate(lang.hitch(this,function(template){
					console.log("template  : ", template);
					console.log("AddContentItemObject:",addContentItemDialog);
					/*var contentClassName = addContentItem._contentClassNameDiv.getFieldWithName("_contentClassNameDiv");
					addContentItem._contentClassDiv.hidden = true;
					addContentItem._contentClassDiv.set("hidden",true);
*/
					/*To hide the PropertiesPane class name field*/
					var styles = domStyle.get(addContentItemDialog.addContentItemPropertiesPane._contentClassNameDiv,"hidden");
					console.log("result",styles);
					console.log(addContentItemDialog.addContentItemGeneralPane._entryTemplateRow.hidden=true);
					console.log("Object Value:",addContentItemDialog.addContentItemPropertiesPane._contentClassNameDiv.hidden=true);

					
					/*This aspect is for loading the default values onCompleteRendering*/
					aspect.after(addContentItemDialog.addContentItemPropertiesPane, "onCompleteRendering", function() {
						var date = new Date("12/31/2017");
						console.log("Date:",date);

						addContentItemDialog.setIntroText("This form is loaded from a right-clicked document.");
						//addContentItemDialog.addContentItemPropertiesPane.setPropertyValue("DocumentTitle", "DocumentTitle");
				        addContentItemDialog.addContentItemPropertiesPane.setPropertyValue("sales_last_contact_date", date);
				        addContentItemDialog.addContentItemPropertiesPane.setPropertyValue("sales_times_contacted", "4");
				    }, true);
					
					/*changing the grid/property template values before rendering
					 * Creating the choice list for Property
					 * Ex:dropdown the cities in the database*/
					aspect.before(addContentItemDialog.addContentItemPropertiesPane,"beforeRenderAttributes",function(attributeDefinitions, item, reason, isReadOnly){
					    for(var i = 0; i < attributeDefinitions.length; i++){

					    	   if(attributeDefinitions[i].hasOwnProperty("id") && attributeDefinitions[i]["id"] === "sales_prospect_name") {
					    	     console.log("SalesProspectName Object:",attributeDefinitions[i]);
					    	     var choiceList = {
					    	    		  "choiceList": {
					    	    			    "choices": [{"displayName":"Reseller","value":"Reseller"},{"displayName":"End User","value":"End User"},
					    	    			    {"choices":[{"displayName":"Motorcycle","value":"Motorcycle"},{"displayName":"Trailer","value":"Trailer"},{"displayName":"Vehicle","value":"Vehicle"}],"displayName":"Dealer"}]
					    	    			  },
					    	    			  "displayName": "Prospect Name"
					    	    			};
					    	     Object.assign(attributeDefinitions[i],choiceList);
					    	     console.log("New Sales Object:",attributeDefinitions[i]);
					    	     
					    	     break;
					    	   }
					    	}
					},true);
					/*This aspect.before is to get the confirmation dialog box before adding the document using entry template */
					function subMethod(){
						var messageDialog = new ecm.widget.dialog.MessageDialog({
							text: "Document Added Successfully!"
						});
						messageDialog.show();
					}

					aspect.after(addContentItemDialog,"onAddFinished",subMethod,true);
					
					addContentItemDialog.show(this.repository, null, true,false, null, null, true, template, null);
				}), false, true);
			}), null, null, null, objectStore);;
		
			
			
			
	/*		var entryTemplate = new ecm.model.EntryTemplate();
			var et = entryTemplate.retrieveEntryTemplate(this.callback, "apply", true);*/
			
			//show(repository, parentFolder, typeDocument, virtualItems, callback, teamspace, useTemplate, entryTemplate, showMultiRepoFolderSelector)
//			addContentItem.show(this.repository, null, true,false, null, null, true, templates[0], null);
			
		},
		callback:function(template){
			
		},
		
		/**
		 * Optional method that sets additional parameters when the user clicks on the launch button associated with 
		 * this feature.
		 */
		setParams: function(params) {
			this.logEntry("setParams", params);
			
			if (params) {
				
				if (!this.isLoaded && this.selected) {
					this.loadContent();
				}
			}
			
			this.logExit("setParams");
		},

		/**
		 * Loads the content of the pane. This is a required method to insert a pane into the LaunchBarContainer.
		 */
		loadContent: function() {
			this.logEntry("loadContent");
			
			if (!this.isLoaded) {
				/**
				 * Add custom load logic here. The LaunchBarContainer widget will call this method when the user
				 * clicks on the launch button associated with this feature.
				 */
				this.isLoaded = true;
				this.needReset = false;
			}
			
			this.logExit("loadContent");
		},

		/**
		 * Resets the content of this pane.
		 */
		reset: function() {
			this.logEntry("reset");
			
			/**
			 * This is an option method that allows you to force the LaunchBarContainer to reset when the user
			 * clicks on the launch button associated with this feature.
			 */
			this.needReset = false;
			
			this.logExit("reset");
		}
	});
});
