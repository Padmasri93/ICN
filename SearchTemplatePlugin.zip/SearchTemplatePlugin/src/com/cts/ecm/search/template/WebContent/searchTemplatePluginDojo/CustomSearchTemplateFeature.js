define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/query",
	"idx/layout/BorderContainer",
	"dijit/layout/ContentPane",
	"dijit/form/TextBox",
	"dijit/form/Button" ,
	"dojo/dom-attr",
	"dojo/dom-style",
	"dojo/dom-construct",
	"ecm/model/Desktop",
	"ecm/model/Request",
	"ecm/model/ResultSet",
	"ecm/widget/layout/_LaunchBarPane",
	"ecm/widget/listView/ContentList",
	"ecm/widget/layout/_RepositorySelectorMixin",
	"ecm/widget/listView/gridModules/RowContextMenu",
	"ecm/widget/listView/modules/Toolbar",
	"ecm/widget/listView/modules/DocInfo",
	"ecm/widget/listView/gridModules/DndRowMoveCopy",
	"ecm/widget/listView/gridModules/DndFromDesktopAddDoc",
	"ecm/widget/listView/modules/Bar",
	"ecm/widget/listView/modules/ViewDetail",
	"ecm/widget/listView/modules/ViewMagazine",
	"ecm/widget/listView/modules/ViewFilmStrip",
	"dojo/text!./templates/CustomSearchTemplateFeature.html"
],
function(declare,
		lang,
		query,
		BorderContainer,
		ContentPane,
		TextBox,
		Button,
		domAttr,
		domStyle,
		domConstruct,
		Desktop,
		Request,
		ResultSet,
		_LaunchBarPane,
		ContentList,
		_RepositorySelectorMixin,
		RowContextMenu,
		Toolbar,
		DocInfo,
		DndRowMoveCopy,
		DndFromDesktopAddDoc,
		Bar,
		ViewDetail,
		ViewMagazine,
		ViewFilmStrip,
		template) {
	/**
	 * @name searchTemplatePluginDojo.CustomSearchTemplateFeature
	 * @class 
	 * @augments ecm.widget.layout._LaunchBarPane
	 */
	return declare("searchTemplatePluginDojo.CustomSearchTemplateFeature", [
		_LaunchBarPane,
		_RepositorySelectorMixin,
	], {
		/** @lends searchTemplatePluginDojo.CustomSearchTemplateFeature.prototype */

		templateString: template,
		
		// Set to true if widget template contains DOJO widgets.
		widgetsInTemplate: true,

		postCreate: function() {
			this.logEntry("postCreate");
			this.inherited(arguments);
			
			domAttr.set(this.searchResults.domNode, "role", "region");
			domAttr.set(this.searchResults.domNode, "aria-label", this.messages.browse_content_list_label);
			this.searchResults.setContentListModules(this.getContentListModules());
			this.searchResults.setGridExtensionModules(this.getContentListGridModules());
			
			this.defaultLayoutRepositoryComponent = "others";
			this.setRepositoryTypes("p8");
			this.createRepositorySelector();
			this.doRepositorySelectorConnections();
			
			// If there is more than one repository in the list, show the selector to the user.
			if (this.repositorySelector.getNumRepositories() > 1) {
				domConstruct.place(this.repositorySelector.domNode, this.repositorySelectorArea, "only");
			}
			/**
			 * Add custom logic (if any) that should be necessary after the feature pane is created. For example,
			 * you might need to connect events to trigger the pane to update based on specific user actions.
			 */
			
			this.logExit("postCreate");
		},
		
		setRepository: function(repository) {
			this.repository = repository;
			if (this.repositorySelector && this.repository) {
				this.repositorySelector.getDropdown().set("value", this.repository.id);

			}
			//this.clear();
		},
		/**
		 * Optional method that sets additional parameters when the user clicks on the launch button associated with 
		 * this feature.
		 */
		setParams: function(params) {
			this.logEntry("setParams", params);
			
			if (params) {
				
				if (!this.isLoaded && this.selected) {
					this.loadContent();
				}
			}
			
			this.logExit("setParams");
		},

		/**
		 * Loads the content of the pane. This is a required method to insert a pane into the LaunchBarContainer.
		 */
		loadContent: function() {
			this.logEntry("loadContent");
			
			if (!this.repository) {
				this.setPaneDefaultLayoutRepository();
			} else if (!this.isLoaded && this.repository && this.repository.connected) {
				this.setRepository(this.repository);
				this.isLoaded = true;
				this.needReset = false;
			}
			
			this.logExit("loadContent");
		},
		
		/**
		 * Runs the search entered by the user.
		 */
		runSearch: function() {
			var requestParams = {};
			requestParams.repositoryId = this.repository.id;
			requestParams.repositoryType = this.repository.type;
			requestParams.memberId = this.memberId.get("value");
			requestParams.memberName = this.memberName.get("value");
			requestParams.documentCategory = this.documentCategory.get("value");
			requestParams.documentType = this.documentType.get("value");
			requestParams.providerName = this.providerName.get("value");
			//To get the Radio Button checked value
			var retreiveSelect = query('#main2 > input[type=radio]:checked');
//			console.log(retreiveSelect[0].defaultValue);
			var default_query = "select * from ImageServices where memberName ";
			if(retreiveSelect[0].defaultValue == "like"){
				var sql_query = default_query + " like "+"'"+"%"+this.memberName.get("value")+"%"+"'";
			}else if(retreiveSelect[0].defaultValue == "equals"){
				var sql_query = default_query + "="+"'"+this.memberName.get("value")+"'";
			}else if(retreiveSelect[0].defaultValue == "starts with"){
				var sql_query = default_query + "like "+"'"+this.memberName.get("value")+"%"+"'";
			}
			console.log(sql_query);
			requestParams.searchQuery = sql_query;
			//requestParams.query = this.appNo.get("value");
			//console.log("Operator : "+document.querySelector('input[name="memberIdOprt"]:checked').value);
			console.log(this.repository.id);
			console.log(this.repository.type);
/*			console.log(document.querySelector('input[name="memberIdOprt"]:checked').value+" "+ this.memberId.get("value"));
			console.log(document.querySelector('input[name="memberNamOprt"]:checked').value+" "+this.memberName.get("value"));
			console.log(document.querySelector('input[name="docCtgryOprt"]:checked').value+" "+this.documentCategory.get("value"));
			console.log(document.querySelector('input[name="docTypeOprt"]:checked').value+" "+this.documentType.get("value"));
			console.log(document.querySelector('input[name="providerNameOprt"]:checked').value +" "+this.providerName.get("value"));*/
			
			
			Request.invokePluginService("SearchTemplatePlugin", "SearchTemplateService",
				{
					requestParams: requestParams,
					requestCompleteCallback: lang.hitch(this, function(response) {	// success
						response.repository = this.repository;
						var resultSet = new ResultSet(response);
						this.searchResults.setResultSet(resultSet);
					})
				}
			);
		},

		/**
		 * Returns the content list grid modules used by this view.
		 * 
		 * @return Array of grid modules.
		 */
		getContentListGridModules: function() {
			var array = [];
			array.push(DndRowMoveCopy);
			array.push(DndFromDesktopAddDoc);
			array.push(RowContextMenu);
			return array;
			},
			
			/**
			 * Returns the content list modules used by this view.
			 * 
			 * @return Array of content list modules.
			 */
			getContentListModules: function() {
			var viewModules = [];
			viewModules.push(ViewDetail);
			viewModules.push(ViewMagazine);
			if (ecm.model.desktop.showViewFilmstrip) {
			viewModules.push(ViewFilmStrip);
			}
			var array = [];
			array.push(DocInfo);
			array.push({
				moduleClass: Bar,
				top: [
					[
						[
							{
								moduleClass: Toolbar
							},
							{
								moduleClasses: viewModules,
								"className": "BarViewModules"
							}
						]
					]
				]
			});
			return array;
		},
		/**
		 * Resets the content of this pane.
		 */
		reset: function() {
			this.logEntry("reset");
			
			if (this.repositorySelector && this.repository)
				this.repositorySelector.getDropdown().set("value", this.repository.id);
			this.needReset = false;
			
			this.logExit("reset");
		},
	});
});
